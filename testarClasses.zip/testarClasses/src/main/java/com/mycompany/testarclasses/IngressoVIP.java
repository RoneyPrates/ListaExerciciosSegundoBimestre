package com.mycompany.testarclasses;

/**
 *
 * @author aluno
 */
public class IngressoVIP extends Ingresso {
    float valorAdicional;
    
    public IngressoVIP(float valor, float ValorAdicional){
    super(valor);
    this.valorAdicional = valorAdicional;
    }
    
    @Override
    public String toString(){
    return "O ingresso VIP está no valor de R$" + (super.valor + this.valorAdicional);
    }
}

