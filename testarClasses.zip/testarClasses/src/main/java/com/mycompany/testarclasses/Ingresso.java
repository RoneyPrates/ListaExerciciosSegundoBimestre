package com.mycompany.testarclasses;

/**
 *
 * @author aluno
 */
public class Ingresso {
    float valor;
    
    public Ingresso(float valor){
    this.valor = valor;
    }
       
    @Override
    public String toString(){
    return "Ingresso está no valor de R$" +this.valor;
    }
}
