
package com.mycompany.testarclasses;

/**
 *
 * @author aluno
 */
public class TestarClasses {

    public static void main(String[] args) {
         Ingresso Ingresso = new Ingresso (50);
    IngressoVIP IngressoVIP = new IngressoVIP (70, 40);
    
    System.out.println(Ingresso.toString());
    System.out.println(IngressoVIP.toString());
    
    IngressoVIP.valorAdicional = 50;
    System.out.println(IngressoVIP.toString());
    }
}
